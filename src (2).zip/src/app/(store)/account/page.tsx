"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowRight, Package, Settings2, ShieldCheck, Sparkles } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

const orders = [
  { id: "AM-4092", item: "Aura Studio Wireless ANC Headphones", date: "Oct 28, 2026", status: "Processing", total: "$189.00" },
  { id: "AM-4031", item: "Nordic Ceramic Ambient Lamp", date: "Oct 14, 2026", status: "Delivered", total: "$64.00" },
];

export default function AccountPage() {
  const router = useRouter();
  const user = useAuth((s) => s.user);
  const signOut = useAuth((s) => s.signOut);

  const handleSignOut = () => {
    signOut();
    router.push("/");
  };

  return (
    <main className="mx-auto max-w-6xl px-4 py-6 sm:px-6 lg:px-8 lg:py-10">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.22em] text-brand">Customer account</p>
          <h1 className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">Your market profile</h1>
          <p className="mt-2 text-ink-muted">Your orders and preferences in one place.</p>
        </div>
        <button onClick={handleSignOut} className="rounded-full border border-line px-4 py-2 text-sm font-semibold text-ink-muted transition-colors hover:border-brand hover:text-brand">
          Sign out
        </button>
      </div>

      <section className="mt-8 rounded-[28px] border border-line bg-panel p-5 sm:p-7">
        <div className="flex flex-wrap items-center gap-4">
          <span className="grid size-16 place-items-center rounded-2xl bg-brand text-2xl font-bold text-brand-ink">{user?.name?.slice(0, 1).toUpperCase() ?? "A"}</span>
          <div className="flex-1">
            <h2 className="text-xl font-bold">{user?.name ?? "Aura member"}</h2>
            <p className="text-sm text-ink-muted">{user?.email ?? "Sign in to sync your account"}</p>
          </div>
          <span className="inline-flex items-center gap-2 rounded-full bg-good-soft px-3 py-1.5 text-xs font-bold text-good"><ShieldCheck className="size-3.5" /> Verified member</span>
        </div>
      </section>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1.35fr_0.65fr]">
        <section>
          <div className="mb-4 flex items-center justify-between"><h2 className="text-xl font-bold">Recent orders</h2><span className="text-sm font-semibold text-brand">2 orders</span></div>
          <div className="space-y-3">
            {orders.map((order) => (
              <article key={order.id} className="rounded-2xl border border-line bg-panel p-4 sm:p-5">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div><p className="text-xs font-bold uppercase tracking-wider text-ink-muted">{order.id} · {order.date}</p><h3 className="mt-2 font-semibold">{order.item}</h3></div>
                  <span className={`rounded-full px-3 py-1 text-xs font-bold ${order.status === "Delivered" ? "bg-good-soft text-good" : "bg-brand/10 text-brand"}`}>{order.status}</span>
                </div>
                <div className="mt-4 flex items-center justify-between border-t border-line pt-3 text-sm"><span className="text-ink-muted">Total paid</span><span className="font-bold">{order.total}</span></div>
              </article>
            ))}
          </div>
        </section>

        <aside className="space-y-3">
          <div className="rounded-2xl border border-line bg-panel p-5">
            <div className="flex items-center gap-3"><span className="grid size-10 place-items-center rounded-xl bg-brand/10 text-brand"><Sparkles className="size-5" /></span><div><p className="font-bold">Aura rewards</p><p className="text-sm text-ink-muted">1,240 points available</p></div></div>
            <div className="mt-4 h-2 rounded-full bg-soft"><div className="h-full w-[62%] rounded-full bg-brand" /></div>
            <p className="mt-2 text-xs text-ink-muted">760 points to your next reward</p>
          </div>
          <Link href="/" className="flex items-center justify-between rounded-2xl border border-line bg-panel p-5 text-sm font-bold transition-colors hover:border-brand/50"><span className="flex items-center gap-3"><Package className="size-5 text-brand" /> Continue shopping</span><ArrowRight className="size-4" /></Link>
          <button type="button" disabled className="flex w-full cursor-not-allowed items-center justify-between rounded-2xl border border-line bg-panel p-5 text-left text-sm font-bold text-ink-muted"><span className="flex items-center gap-3"><Settings2 className="size-5 text-brand" /> Account settings</span><span className="text-xs font-medium">Soon</span></button>
        </aside>
      </div>
    </main>
  );
}
